package services;

import exceptions.InvalidPaymentException;

public class PaymentService {
    public void processPayment(double amount, String paymentMethod, double cardBalance) 
            throws InvalidPaymentException {
        if (!paymentMethod.equalsIgnoreCase("card") && !paymentMethod.equalsIgnoreCase("cash")) {
            throw new InvalidPaymentException("Invalid Payment. Only 'card' or 'cash' accepted.");
        }

        if (paymentMethod.equalsIgnoreCase("card") && cardBalance < amount) {
            throw new InvalidPaymentException("Invalid Payment. Insufficient funds.");
        }
    }

    public double getUpdatedCardBalance(double amount, double cardBalance) {
        return cardBalance - amount;
    }
}