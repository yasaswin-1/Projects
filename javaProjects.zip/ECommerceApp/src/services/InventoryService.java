package services;

import models.Product;
import exceptions.OutOfStockException;
import java.util.ArrayList;
import java.util.List;

public class InventoryService {
    private List<Product> products;

    public InventoryService() {
        this.products = new ArrayList<>();
        // Initialize with some sample products
        initializeInventory();
    }

    private void initializeInventory() {
        products.add(new Product(101, "Wireless Mouse", 599.00, 10));
        products.add(new Product(102, "USB Keyboard", 799.00, 0));
        products.add(new Product(103, "Power Bank", 1499.00, 5));
    }

    public List<Product> getAllProducts() {
        return products;
    }

    public Product getProductById(int id) {
        return products.stream()
                .filter(product -> product.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public void checkStock(Product product) throws OutOfStockException {
        if (product.getStockQuantity() <= 0) {
            throw new OutOfStockException("Cannot add product. Product '" + product.getName() + "' is out of stock.");
        }
    }
}