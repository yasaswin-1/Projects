package services;

import models.User;
import java.util.HashMap;
import java.util.Map;

public class AuthService {
    private Map<String, User> users;

    public AuthService() {
        this.users = new HashMap<>();
        // Initialize with some sample users
        users.put("john_doe", new User("john_doe", "password123", "John Doe"));
        users.put("jane_smith", new User("jane_smith", "securepass", "Jane Smith"));
    }

    public User authenticate(String username, String password) {
        User user = users.get(username);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null;
    }
}