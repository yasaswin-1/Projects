package main;

import models.*;
import services.*;
import exceptions.*;
import java.util.Scanner;
import java.util.List;
import java.util.Random;

public class ECommerceApp {
    private static Scanner scanner = new Scanner(System.in);
    private static AuthService authService = new AuthService();
    private static InventoryService inventoryService = new InventoryService();
    private static PaymentService paymentService = new PaymentService();
    private static Cart cart;
    private static User currentUser;

    public static void main(String[] args) {
        showWelcomeScreen();
    }

    private static void showWelcomeScreen() {
        System.out.println("====== Welcome to E-Shop ======\n");
        System.out.println("1. Login");
        System.out.println("2. Exit");
        System.out.print("Enter your choice: ");
        
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                login();
                break;
            case 2:
                System.out.println("Thank you for visiting E-Shop. Goodbye!");
                System.exit(0);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
                showWelcomeScreen();
        }
    }

    private static void login() {
        System.out.print("\nEnter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        currentUser = authService.authenticate(username, password);
        if (currentUser != null) {
            cart = new Cart();
            System.out.println("\nLogin successful! Welcome, " + currentUser.getName() + ".");
            showMainMenu();
        } else {
            System.out.println("\nLogin failed. Invalid credentials.");
            showWelcomeScreen();
        }
    }

    private static void showMainMenu() {
        System.out.println("\n------ MAIN MENU ------");
        System.out.println("1. View Products");
        System.out.println("2. Add Product to Cart");
        System.out.println("3. View Cart");
        System.out.println("4. Remove Product from Cart");
        System.out.println("5. Place Order");
        System.out.println("6. Logout");
        System.out.print("Enter your choice: ");

        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                viewProducts();
                break;
            case 2:
                addToCart();
                break;
            case 3:
                viewCart();
                break;
            case 4:
                removeFromCart();
                break;
            case 5:
                placeOrder();
                break;
            case 6:
                logout();
                return;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
        showMainMenu();
    }

    private static void viewProducts() {
        System.out.println("\n--- Available Products ---");
        List<Product> products = inventoryService.getAllProducts();
        for (Product product : products) {
            product.displayDetails();
        }
    }

    private static void addToCart() {
        viewProducts();
        System.out.print("\nEnter Product ID to add to cart: ");
        int productId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Product product = inventoryService.getProductById(productId);
        if (product == null) {
            System.out.println("Error: Product not found.");
            return;
        }

        try {
            inventoryService.checkStock(product);
            cart.addProduct(product);
            System.out.println("\nProduct '" + product.getName() + "' added to cart.");
        } catch (OutOfStockException e) {
            System.out.println("\nError: " + e.getMessage());
        }
    }

    private static void viewCart() {
        cart.viewCart();
    }

    private static void removeFromCart() {
        if (cart.getItems().isEmpty()) {
            System.out.println("Your cart is empty.");
            return;
        }

        viewCart();
        System.out.print("\nEnter item number to remove: ");
        int itemNumber = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        if (itemNumber < 1 || itemNumber > cart.getItems().size()) {
            System.out.println("Invalid item number.");
            return;
        }

        Product product = cart.getItems().get(itemNumber - 1);
        cart.removeProduct(product);
        System.out.println("Product '" + product.getName() + "' removed from cart.");
    }

    private static void placeOrder() {
        if (cart.getItems().isEmpty()) {
            System.out.println("Your cart is empty. Cannot place order.");
            return;
        }

        System.out.println("\n--- Place Order ---");
        System.out.printf("Total Amount: ₹%,.2f%n", cart.calculateTotal());

        System.out.print("Enter Payment Method (card/cash): ");
        String paymentMethod = scanner.nextLine();

        double cardBalance = 0;
        if (paymentMethod.equalsIgnoreCase("card")) {
            System.out.print("Enter Card Balance: ");
            cardBalance = scanner.nextDouble();
            scanner.nextLine(); // Consume newline
        }

        try {
            paymentService.processPayment(cart.calculateTotal(), paymentMethod, cardBalance);
            
            // Generate random order ID
            String orderId = "ORD" + new Random().nextInt(90000) + 10000;
            Order order = new Order(orderId, cart.getItems());
            order.confirmOrder();
            
            System.out.println("\nOrder confirmed! 🎉");
            order.displayOrderDetails();
            
            if (paymentMethod.equalsIgnoreCase("card")) {
                double remainingBalance = paymentService.getUpdatedCardBalance(
                    cart.calculateTotal(), cardBalance);
                System.out.printf("Remaining Card Balance: ₹%,.2f%n", remainingBalance);
            }
            
            System.out.println("\nStock updated.");
            cart.clear();
        } catch (InvalidPaymentException | OutOfStockException e) {
            System.out.println("\nError: " + e.getMessage());
        }
    }

    private static void logout() {
        System.out.println("\nLogging out...");
        System.out.println("Thank you for shopping with us!");
        currentUser = null;
        cart = null;
        showWelcomeScreen();
    }
}