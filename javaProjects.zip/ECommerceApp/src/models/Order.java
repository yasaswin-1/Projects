package models;

import exceptions.OutOfStockException;
import java.util.List;

public class Order {
    private String orderId;
    private List<Product> items;
    private double totalAmount;

    public Order(String orderId, List<Product> items) {
        this.orderId = orderId;
        this.items = items;
        this.totalAmount = calculateTotal();
    }

    private double calculateTotal() {
        return items.stream().mapToDouble(Product::getPrice).sum();
    }

    public void confirmOrder() throws OutOfStockException {
        // Check stock before confirming order
        for (Product product : items) {
            if (product.getStockQuantity() <= 0) {
                throw new OutOfStockException("Product '" + product.getName() + "' is out of stock.");
            }
        }
        
        // Update stock
        for (Product product : items) {
            product.setStockQuantity(product.getStockQuantity() - 1);
        }
    }

    public void displayOrderDetails() {
        System.out.println("Order ID: " + orderId);
        System.out.println("Items Purchased: " + items.size());
        System.out.printf("Total Paid: ₹%,.2f%n", totalAmount);
    }

    public double getTotalAmount() {
        return totalAmount;
    }
}