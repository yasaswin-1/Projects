package models;

public class Movie {
    private int id;
    private String name;
    private String genre;
    private int availableSeats;
    private double price;

    public Movie(int id, String name, String genre, int availableSeats, double price) {
        this.id = id;
        this.name = name;
        this.genre = genre;
        this.availableSeats = availableSeats;
        this.price = price;
    }

    // Getters and setters
    public int getId() { return id; }
    public String getName() { return name; }
    public String getGenre() { return genre; }
    public int getAvailableSeats() { return availableSeats; }
    public void setAvailableSeats(int seats) { this.availableSeats = seats; }
    public double getPrice() { return price; }

    @Override
    public String toString() {
        return String.format("ID: %d | Name: %-10s | Genre: %-6s | Available Seats: %d | Price: Rs.%.2f",
                id, name, genre, availableSeats, price);
    }
}