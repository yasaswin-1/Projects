package services;

import models.User;
import exceptions.*;

public class BookingService {
    private MovieService movieService;

    public BookingService(MovieService movieService) {
        this.movieService = movieService;
    }

    public void processBooking(User user, int movieId) throws InvalidMovieIDException, SeatAlreadyBookedException {
        movieService.bookSeat(movieId);
    }
}