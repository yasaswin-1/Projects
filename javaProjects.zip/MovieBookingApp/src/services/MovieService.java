package services;

import models.Movie;
import exceptions.*;
import java.util.LinkedHashMap;

public class MovieService {
    private LinkedHashMap<Integer, Movie> movies;

    public MovieService() {
        movies = new LinkedHashMap<>();
        initializeMovies();
    }

    private void initializeMovies() {
        movies.put(101, new Movie(101, "Inception", "Sci-Fi", 3, 250));
        movies.put(102, new Movie(102, "Dangal", "Drama", 0, 180));
        movies.put(103, new Movie(103, "Avengers", "Action", 5, 300));
    }

    public void displayMovies() {
        System.out.println("--- Available Movies ---");
        for (Movie movie : movies.values()) {
            System.out.println(movie);
        }
    }

    public Movie getMovieById(int movieId) throws InvalidMovieIDException {
        Movie movie = movies.get(movieId);
        if (movie == null) {
            throw new InvalidMovieIDException("Movie ID not found");
        }
        return movie;
    }

    public void bookSeat(int movieId) throws SeatAlreadyBookedException, InvalidMovieIDException {
        Movie movie = getMovieById(movieId);
        if (movie.getAvailableSeats() <= 0) {
            throw new SeatAlreadyBookedException("No seats available");
        }
        movie.setAvailableSeats(movie.getAvailableSeats() - 1);
    }
}