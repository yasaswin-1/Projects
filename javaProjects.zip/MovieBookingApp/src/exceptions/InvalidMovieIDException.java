package exceptions;

public class InvalidMovieIDException extends Exception {
    public InvalidMovieIDException(String message) {
        super(message);
    }
}