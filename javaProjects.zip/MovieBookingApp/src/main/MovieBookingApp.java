package main;


import models.Movie;  // Add this line
import models.User;
import services.MovieService;
import services.BookingService;
import exceptions.*;
import java.util.*;

public class MovieBookingApp {
    private static Scanner scanner = new Scanner(System.in);
    private static MovieService movieService = new MovieService();
    private static BookingService bookingService = new BookingService(movieService);
    private static Map<String, User> users = new HashMap<>();
    private static User currentUser;
    private static int userIdCounter = 1;

    public static void main(String[] args) {
        System.out.println("===== Welcome to CineBook =====");
        boolean exit = false;

        while (!exit) {
            System.out.println("\n1. Login\n2. Exit");
            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    handleLogin();
                    if (currentUser != null) showMainMenu();
                    break;
                case 2:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        }
        System.out.println("Thank you for using CineBook!");
    }

    private static void handleLogin() {
        System.out.print("\nEnter Email: ");
        String email = scanner.nextLine();
        System.out.print("Enter Name: ");
        String name = scanner.nextLine();

        currentUser = users.get(email);
        if (currentUser == null) {
            currentUser = new User(userIdCounter++, name, email);
            users.put(email, currentUser);
            System.out.println("\nLogin successful! Welcome, " + name);
        } else {
            System.out.println("\nWelcome back, " + name);
        }
    }

    private static void showMainMenu() {
        boolean back = false;
        while (!back) {
            System.out.println("\n------ MAIN MENU ------");
            System.out.println("1. View Movies\n2. Book Ticket\n3. Exit");
            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    movieService.displayMovies();
                    break;
                case 2:
                    handleBooking();
                    break;
                case 3:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }

    private static void handleBooking() {
        System.out.print("\nEnter Movie ID: ");
        int movieId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try {
            bookingService.processBooking(currentUser, movieId);
            Movie movie = movieService.getMovieById(movieId);
            System.out.println("\nBooking successful! 🎟️");
            System.out.println("User: " + currentUser.getName());
            System.out.println("Movie: " + movie.getName());
            System.out.println("Remaining seats: " + movie.getAvailableSeats());
        } catch (InvalidMovieIDException e) {
            System.out.println("Error: Invalid Movie ID");
        } catch (SeatAlreadyBookedException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}